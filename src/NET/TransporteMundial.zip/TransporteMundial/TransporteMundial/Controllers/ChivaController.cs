﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using TransporteMundial.DataAcces;
using TransporteMundial.Models;

namespace TransporteMundial.Controllers
{
    public class ChivaController : Controller
    {
        private TransporteDBContext _transporteDBContext = new TransporteDBContext();
        [HttpPost]
        public ActionResult SaveChiva(Chiva chiva)
        {
            _transporteDBContext.Chivas.Add(chiva);
            int savedRecords = _transporteDBContext.SaveChanges();
            var result = new { SavedRecords = savedRecords };
            return Json(result);
        }

        public ActionResult GetAllChivas()
        {
            return Json(_transporteDBContext.Chivas.ToList(), JsonRequestBehavior.AllowGet);
        }

        protected override void Dispose(bool disposing)
        {
            if (disposing)
            {
                _transporteDBContext.Dispose();
            }
            base.Dispose(disposing);
        }
    }
}