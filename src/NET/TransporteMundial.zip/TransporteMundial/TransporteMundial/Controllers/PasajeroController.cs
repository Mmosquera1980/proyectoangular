﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using TransporteMundial.DataAcces;
using TransporteMundial.Models;

namespace TransporteMundial.Controllers
{
    public class PasajeroController : Controller
    {
        private TransporteDBContext _transporteDBContext = new TransporteDBContext();
        [HttpPost]
        public ActionResult SavePasajero(Pasajero pasajero)
        {
            _transporteDBContext.Pasajeros.Add(pasajero);
            int savedRecords = _transporteDBContext.SaveChanges();
            var result = new { SavedRecords = savedRecords };
            return Json(result);
        }

        public ActionResult GetAllPasajeros()
        {
            return Json(_transporteDBContext.Pasajeros.ToList(), JsonRequestBehavior.AllowGet);
        }

        protected override void Dispose(bool disposing)
        {
            if (disposing)
            {
                _transporteDBContext.Dispose();
            }
            base.Dispose(disposing);
        }
    }
}