﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using TransporteMundial.Models;
using TransporteMundial.DataAcces;

namespace TransporteMundial.Controllers
{
    public class TiqueteController : Controller
    {
        private TransporteDBContext _transporteDBContext = new TransporteDBContext();
        [HttpPost]
        public ActionResult SaveTiquete(Tiquete tiquete)
        {
            _transporteDBContext.Tiquetes.Add(tiquete);
            int savedRecords = _transporteDBContext.SaveChanges();
            var result = new { SavedRecords = savedRecords };
            return Json(result);
        }

        public ActionResult GetAllTiquetes()
        {
            return Json(_transporteDBContext.Tiquetes.ToList(), JsonRequestBehavior.AllowGet);
        }

        protected override void Dispose(bool disposing)
        {
            if (disposing)
            {
                _transporteDBContext.Dispose();
            }
            base.Dispose(disposing);
        }
    }
}