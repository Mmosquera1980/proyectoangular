﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using TransporteMundial.Models;
using System.Data.Entity;

namespace TransporteMundial.DataAcces
{
    public class TransporteDBContext : DbContext
    {
        public DbSet<Chiva> Chivas { get; set; }

        public DbSet<Pasajero> Pasajeros { get; set; }

        public DbSet<Viaje> Viajes { get; set; }

        public DbSet<Tiquete> Tiquetes { get; set; }
    }
}