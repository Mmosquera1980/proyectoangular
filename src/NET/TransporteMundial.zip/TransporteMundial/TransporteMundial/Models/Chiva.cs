﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.ComponentModel.DataAnnotations;

namespace TransporteMundial.Models
{
    public class Chiva
    {
        public int id { get; set; }

        [Required]
        public String nombre { get; set; }

        [Required]
        public String placa { get; set; }

        [Required]
        public String puestos { get; set; }

        [Required]
        public String combustible { get; set; }

        [Required]
        public String modelo { get; set; }
    }
}