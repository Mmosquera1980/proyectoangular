﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.ComponentModel.DataAnnotations;

namespace TransporteMundial.Models
{
    public class Pasajero
    {
        public int id { get; set; }

        [Required]
        public String cedula { get; set; }

        [Required]
        public String nombre { get; set; }

        [Required]
        public String telefono { get; set; }

        [Required]
        public int edad { get; set; }
    }
}