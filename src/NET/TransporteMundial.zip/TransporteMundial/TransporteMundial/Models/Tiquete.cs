﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.ComponentModel.DataAnnotations;

namespace TransporteMundial.Models
{
    public class Tiquete
    {
        public int id { get; set; }

        [Required]
        public String codigo { get; set; }

        [Required]
        public String pasajero { get; set; }

        [Required]
        public String chiva { get; set; }

        [Required]
        public String viaje { get; set; }
    }
}